import React from 'react'
import '../App.css';

const Header = () => {
  return (
    <div className="react-chatbot-kit-chat-header">
      Ask EIP
    </div>
  )
}

export default Header
